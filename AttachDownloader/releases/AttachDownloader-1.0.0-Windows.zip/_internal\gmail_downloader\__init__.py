"""
AttachDownloader - Herramienta profesional para descargar y organizar adjuntos de Gmail
"""

__version__ = "1.0.0"
__author__ = "GitHub Copilot"
__project__ = "AttachDownloader"
